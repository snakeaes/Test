<script lang="ts">
    import "$lib/styles/main.css";

    export let header: String = "";  
    export let buttons: Map<String, String> = new Map();
</script>

<div id="wrapper">
    <main>
        <h1>{header}</h1>

        {#each Array.from(buttons, ([path, text]) => ({ path, text })) as { path, text }}
            <button on:click={() => {window.location.href = path}}>{text}</button>
        {/each}
    </main>
</div>

<style>
    main {
        padding: 5vw;

        width: 40vw;
        height: auto;

        display: flex;
        flex-direction: column;
        gap: 2vw;

        background: rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        backdrop-filter: blur(11.2px);
        -webkit-backdrop-filter: blur(11.2px);
        border: 1px solid rgba(255, 255, 255, 0.3);
    }

    button {
        width: 40vw;
        height: 4.25vw;

        color: #000;
        text-decoration: none;
        text-align: center;
        align-content: center;
        border-radius: 1vw;
        border: 2px solid #00d9ff;
        background-color: #fff;

        font-size: 2vw;
    }
</style>