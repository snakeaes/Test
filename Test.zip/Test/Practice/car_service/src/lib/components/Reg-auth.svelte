<script lang="ts">
    import axios from "axios";

    export let header: String = "";
    export let buttonName: String = "";
    export let linkName: String = "";
    export let linkPath: String = "";

    const Auth = async () => {
        const login = document.getElementById("login") as HTMLInputElement; // Ваши данные для логина
        const password = document.getElementById("password") as HTMLInputElement; // Ваши данные для пароля

        axios.get('http://localhost:3000/get_admin', {
            params: {
                login: login.value,
                password: password.value
            }
        })
        .then(response => {
            const data = response.data;

            if (data.message) {
                console.log("Авторизация прошла успешно");
                window.location.href = "/admin";
            }
        })
        .catch(err => {
            console.error(err);
        });
    };
</script>

<div id="menu">
    <h1>{header}</h1>
    <input id="login" type="login" placeholder="Введите логин">
    <input id="password" type="password" placeholder="Введите пароль">

    {#if header === "Авторизация"}
        <button on:click={Auth} id="btn_auth">{buttonName}</button>
    {/if}
    {#if header === "Регистрация"}
        <button id="btn_reg">{buttonName}</button>
    {/if}

    <a on:click={() => {window.location.href = linkPath}}>{linkName}</a>
</div>

<style>
    #menu {
        padding: 5vw;

        width: 40vw;
        height: auto;
        
        display: flex;
        flex-direction: column;
        justify-content: center;
        gap: 2vw;

        background: rgba(255, 255, 255, 0.2);
        border-radius: 16px;
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        backdrop-filter: blur(11.2px);
        -webkit-backdrop-filter: blur(11.2px);
        border: 1px solid rgba(255, 255, 255, 0.3);
    }

    h1 {
        color: #fff;
        text-align: center;

        font-size: 3vw;
    }

    input {
        height: 4.25vw;

        padding-left: 2vw;

        font-size: 2vw;
        border-radius: 1vw;
        border: 2px solid #00d9ff;
        background: white;
    }

    button {
        width: 100%;
        height: 5vw;

        border-radius: 1vw;
        border: 2px solid #00d9ff;
        font-size: 2vw;
    }

    a {
        color: #fff;
        font-size: 2vw;
        text-decoration: none;
        text-align: center;
    }
</style>