<script lang="ts">
    import "$lib/styles/main.css";
    import RegAuth from "$lib/components/Reg-auth.svelte";

    const header: String = "Авторизация";
    const buttonName: String = "Войти";
    const linkName: String = "Продолжить как клиент";
    const linkPath: String = "/client";
</script>

<div id="wrapper">
    <RegAuth {header} {buttonName} {linkName} {linkPath}></RegAuth>
</div>