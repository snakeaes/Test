<script lang="ts">
    import "$lib/styles/main.css";

    import Menu from "$lib/components/Menu.svelte";
    let header = "Меню"
    let buttons: Map<String, String> = new Map();
    buttons.set("/admin/client", "Клиенты");
    buttons.set("/admin/application", "Заявки");
    buttons.set("/admin/check", "Чеки");
    buttons.set("/", "Назад");
</script>

<Menu {header} buttons={buttons}></Menu>