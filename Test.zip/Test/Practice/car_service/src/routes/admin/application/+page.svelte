<script lang="ts">
    import "$lib/styles/main.css";
    import axios from "axios";
    import { onMount } from "svelte";

    let target: HTMLElement;


    const Exit = () => {
        const modal = document.getElementById("modal");
        modal ? modal.style.display = "none" : console.error("Ошибка");
    }


    const Save = () => {
    console.log("Работаю");

    console.log(target);
    const node = target.parentElement;
    const idText = node?.querySelector("p")?.textContent;
    console.log(node);
    console.log(idText);

    const numberPuttern = /\d+/;
    const match = idText?.match(numberPuttern);

    if (match) {
        const id = parseInt(match[0], 10);
        console.log("Извлеченное число: ", id);

        const full_name = document.getElementById("full_name") as HTMLInputElement;
        const phone_number = document.getElementById("phone_number") as HTMLInputElement;
        const type_equipment = document.getElementById("type_equipment") as HTMLInputElement;
        const problem = document.getElementById("problem") as HTMLInputElement;
        const date = document.getElementById("date") as HTMLInputElement;
        const status = document.getElementById("status") as HTMLInputElement;
        const userData = {
            id: id.toString(),
            full_name: full_name.value,
            phone_number: phone_number.value,
            type_equipment: type_equipment.value,
            problem: problem.value,
            date_application: date.value,
            status: status.value
        };

        axios.post("http://localhost:3000/upd_user", userData)
            .then(response => {
                console.log(response.data);
            })
            .catch(error => {
                console.error(error);
            });
        };
    }


    onMount(() => {

        const applicationContainer  = document.getElementById("application__container");
        const modal                 = document.getElementById("modal");

        applicationContainer?.addEventListener("click", (event) => {
            
            const targetElement = event.target as HTMLElement;
            target = targetElement;

            if (targetElement) {
                const closestBtnEdit = targetElement.closest(".btn_edit");

                if (closestBtnEdit) {
                    const node = closestBtnEdit.parentElement;

                    const fieldValues             = node.querySelectorAll("p");

                    let pastFullName:           String | null;;
                    let pastPhoneNumber:        String | null;
                    let pastTypeEquipment:      String | null;
                    let pastStatus:             String | null;
                    let pastDate:                Date | null;

                    modal ? modal.style.display = "block" : console.error("Ошибка");
                    
                    console.log(fieldValues[2].textContent);
                    

                    for (let i = 1; i < fieldValues.length; i++) {
                        switch (i) {
                            case 0: break;
                            case 1:
                                pastPhoneNumber     = fieldValues[i].textContent;
                            break;
                            case 2:
                                pastFullName        = fieldValues[i].textContent;
                            break;
                            case 3:
                                pastPhoneNumber     = fieldValues[i].textContent;
                            break;
                            case 4: 
                                pastTypeEquipment   = fieldValues[i].textContent;
                            break;
                            case 5:
                                pastDate            = fieldValues[i].textContent;
                            break;
                            case 6:
                                pastStatus          = fieldValues[i].textContent;
                            break;
                            default: break;
                        }
                    }
                    
                    const words                     = pastDate.split(" ");
                    const pastdateParse             = words[words.length - 1];
                    
                    
                    const full_name                 = document.getElementById("full_name")          as HTMLInputElement;
                    const phone_number              = document.getElementById("phone_number")       as HTMLInputElement;
                    const type_equipment            = document.getElementById("type_equipment")     as HTMLInputElement;
                    const problem                   = document.getElementById("problem")            as HTMLInputElement;
                    const status                    = document.getElementById("status")             as HTMLInputElement;
                    const date                      = document.getElementById("date")               as HTMLInputElement;

                    full_name.placeholder           = `${pastFullName || ''}`;
                    phone_number.placeholder        = `${pastPhoneNumber || ''}`;
                    type_equipment.placeholder      = `${pastTypeEquipment || ''}`;
                    problem.placeholder             = "Описание проблемы";
                    status.placeholder              = `${pastStatus || ''}`;
                    date.value                      = `${pastdateParse || ''}`;
                }

                const closestBtnCheck = targetElement.closest(".btn_check");

                if (closestBtnCheck) {
                    const node = closestBtnCheck.parentElement;

                    console.log(node);

                    const fieldValues           = node.querySelectorAll("p");

                    let fullName:               String | null;;
                    let phoneNumber:            String | null;
                    let typeEquipment:          String | null;
                    let date:                   Date | null;

                    const price = prompt("Введите цену");

                    for (let i = 1; i < fieldValues.length; i++) {
                        console.log(fieldValues[i], i);
                        
                        switch (i) {
                            case 0: break;
                            case 1:

                            break;
                            case 2:
                                fullName        = fieldValues[i].textContent;
                            break;
                            case 3: 
                                phoneNumber     = fieldValues[i].textContent; 
                            break;
                            case 4: 
                                typeEquipment   = fieldValues[i].textContent;
                            break;
                            case 5:
                                date            = fieldValues[i].textContent;
                            break;
                            case 6: break;
                            default: break;
                        }
                    }     

                    const Check = {
                        full_name: fullName,
                        phone_number: phoneNumber,
                        type_equipment: typeEquipment,
                        date_check: date,
                        price: `Итоговая цена ${price}`
                    }

                    console.log(Check);
                    

                    axios.post("http://localhost:3000/add_check", Check)
                        .then(response => {
                            console.log(response.data);
                            alert("Чек создан");
                        })
                        .catch(err => {
                            console.error(err);
                        })
                    
                }
            }
        })

        axios.get('http://localhost:3000/get_application')
        .then(response => {
            for (let i = 0; i < response.data.length; i++) {
                let elem                            = response.data[i];

                const application                   = document.createElement("div");
                application.style.fontSize          = "1.25vw";
                application.style.display           = "flex";
                application.style.flexDirection     = "column";
                application.style.alignItems        = "center";
                application.style.gap               = "0.5vw";
                application.style.backgroundColor   = "#0000006e";
                application.style.paddingTop        = "1vw";
                application.style.paddingBottom     = "1vw";
                application.style.borderRadius      = "1vw";

                const id                            = document.createElement("p");
                id.textContent                      = `Номер заказа ${elem.id}`;

                const date                          = document.createElement("p");
                date.textContent                    = `Дата ${elem.date_application}`;

                const full_name                     = document.createElement("p");
                full_name.textContent               = `ФИО ${elem.full_name}`;

                const phone_number                  = document.createElement("p");
                phone_number.textContent            = `Номер телефона ${elem.phone_number}`;

                const type_equipment                = document.createElement("p");
                type_equipment.textContent          = `Тип неисправности ${elem.type_equipment}`;

                const date_application              = document.createElement("p");
                date_application.textContent        = `Дата окончания ремонта ${elem.date_application}`;

                const status                        = document.createElement("p");
                status.textContent                  = `${elem.status}`;
                status.style.marginBottom           = "1vw";

                const applicEdit                    = document.createElement("button");
                applicEdit.textContent              = "Редатировать заявку";
                applicEdit.className                = "btn_edit";

                const createCheck                   = document.createElement("button");
                createCheck.textContent             = "Создать чек";
                createCheck.className               = "btn_check";

                applicationContainer?.appendChild(application);
                application.append(id, date, full_name, phone_number, type_equipment, date_application, status, applicEdit, createCheck);
            }
        })
        .catch(err => {
            console.error(err);
        });
    })
</script>


<div id="wrapper">
    <main>
        <h1>Заявки</h1>

        <div id="application__container"></div>
        <a href="/admin">Назад</a>
    </main>

    <div id="modal" style="display: none">

        <div id="modal__content">
            <button on:click={Exit} id="btn_exit" class="btn">Назад</button>

            <input id="full_name" class="input__edit" type="text">
            <input id="phone_number" class="input__edit" type="text"> 
            <input id="type_equipment" class="input__edit" type="text"> 
            <textarea id="problem" class="textrea__edit"></textarea> 
            <input id="status" class="input__edit" type="text">
            <input id="date" class="input__edit" type="date"> 

            <button on:click={Save} id="btn_save" class="btn">Сохранить изменения</button>
        </div>


    </div>
</div>


<style>
    main {
        width: 40vw;
        height: auto;
    }

    #application__container {
        height: auto;

        display: flex;
        flex-direction: column;
        gap: 2vw;
        text-align: center;
    }

    #modal {
        width: 100%;
        height: 100%;

        position: fixed;
        left: 0;
        top: 0;

        background-color: #00000080;
    }

    #modal__content {
        width: 100%;
        height: 100%;

        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 1vw;
    }

    .input__edit {
        padding: 1.25vw;

        width: 30vw;
        height: 0.5vw;application__container

        width: 30.5vw;
        height: 15vw;

        resize: none;

        font-size: 2vw;
        border: 2px solid #00d9ff;
        border-radius: 1vw;
    }

    .btn {
        width: 32.6vw;
        height: 3vw;

        border-radius: 1vw;
        border: 2px solid #00d9ff;
        font-size: 2vw;
    }
</style>