<script lang="ts">
    import "$lib/styles/main.css";
    import axios from "axios";
    import { onMount } from "svelte";

    onMount(() => {
        const checkContainer  = document.getElementById("check__container");

        axios.get('http://localhost:3000/get_check')
            .then(response => {
                console.log(response.data);

                for (let i = 0; i < response.data.length; i++) {
                let elem                            = response.data[i];

                const check                         = document.createElement("div");
                check.style.fontSize                = "1.25vw";
                check.style.display                 = "flex";
                check.style.flexDirection           = "column";
                check.style.alignItems              = "center";
                check.style.gap                     = "0.5vw";
                check.style.backgroundColor         = "#0000006e";
                check.style.padding                 = "1vw";
                check.style.borderRadius            = "1vw";

                const full_name                     = document.createElement("p");
                full_name.textContent               = elem.full_name;

                const phone_number                  = document.createElement("p");
                phone_number.textContent            = elem.phone_number;

                const type_equipment                = document.createElement("p");
                type_equipment.textContent          = elem.type_equipment;

                const date_check                    = document.createElement("p");
                date_check.textContent              = elem.date_check;

                const price                         = document.createElement("p");
                price.textContent                   = elem.price;

                checkContainer?.appendChild(check);
                check.append(full_name, phone_number, type_equipment, date_check, price);
            }

            })
            .catch(err => {
                console.error(err);
            })
    })
</script>

<div id="wrapper">
    <main>
        <h1>Чеки</h1>

        <div id="check__container"></div>
        <a href="/admin">Назад</a>
    </main>
</div>


<style>
    main {
        width: 40vw;
        height: auto;
    }

    #check {
        height: auto;

        display: flex;
        flex-direction: column;
        gap: 2vw;
        text-align: center;
    }
</style>