<script lang="ts">
    import "$lib/styles/main.css";

    import Menu from "$lib/components/Menu.svelte";
    const header = "Администратор";
    let buttons: Map<String, String> = new Map();
    buttons.set("/admin/client/add_applic", "Создать заказ");
    buttons.set("/admin/client/view_applic", "Заказы");
    buttons.set("/admin", "Назад");
</script>

<Menu {header} buttons={buttons}></Menu>