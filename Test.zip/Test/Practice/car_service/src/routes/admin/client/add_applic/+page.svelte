<script lang="ts">
    import "$lib/styles/main.css";
    import axios from "axios";

    const AddAplic = () => {

        const fullName = document.getElementById("full_name") as HTMLInputElement;
        const phoneNumber = document.getElementById("phone_number") as HTMLInputElement;
        const typeEquipment = document.getElementById("type_equipment") as HTMLInputElement;
        const problem = document.getElementById("problem") as HTMLInputElement;
        const date = document.getElementById("date") as HTMLInputElement;
        const status: String = "В работе";

        const User = {
            full_name: fullName.value,
            phone_number: phoneNumber.value,
            type_equipment: typeEquipment.value,
            problem: problem.value,
            date_application: date.value,
            status: status
        };

        axios.post("http://localhost:3000/add_user", User)
            .then(response => {
                console.log(response.data);
            })
            .catch(err => {
                console.error(err);
            })
    }
</script>

<div id="wrapper">
    <main>
        <h1>Создание заказа</h1>

        <input id="full_name" type="text" placeholder="Иванов Иван Иванович">
        <input id="phone_number" type="text" placeholder="8 (999) 999-99-99"> 
        <input id="type_equipment" type="text" placeholder="Тип оборудования"> 
        <textarea id="problem" placeholder="Описание проблемы"></textarea> 
        <input id="date" type="date"> 
    
        <button on:click={AddAplic}>Подтвердить</button>
        <a href="/admin/client">Назад</a>
    </main>
</div>

<style>
    main {
        padding-top: 2vw;
        padding-bottom: 2vw;
    }

    input {
        padding: 1.25vw;

        width: 40vw;
        height: 5vw;

        font-size: 2vw;
        border: 2px solid #00d9ff;
        border-radius: 1vw;
    }
    textarea {
        padding: 1.25vw;

        width: 40vw;
        height: 40vw;

        resize: none;

        font-size: 2vw;
        border: 2px solid #00d9ff;
        border-radius: 1vw;
    }

    button {
        width: 43vw;
        height: 7vw;

        border-radius: 1vw;
        border: 2px solid #00d9ff;
        font-size: 2vw;
    }
</style>