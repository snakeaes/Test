<script lang="ts">
    import "$lib/styles/main.css";
    import axios from "axios";

    
//     const ViewAplic = () => {
//     const phoneNumber = document.getElementById("phone_number") as HTMLInputElement | null;
    
//     if (phoneNumber) {

//     axios.get("http://localhost:3000/get_user", {
//         params: {
//             phone_number: phoneNumber.value
//         }
//     })
//     .then(response => {
//         console.log(response.data);
//     })
//     .catch(err => {
//         console.error(err);
//     });
// }
// };

const ViewAplic = () => {
        const phoneNumber = document.getElementById("phone_number") as HTMLInputElement | null;
    
        if (phoneNumber) {
            axios.get("http://localhost:3000/get_user", {
                params: {
                    phone_number: phoneNumber.value
                }
            })
            .then(response => {
                const data = response.data;

                let application = document.getElementById("application");

                const date                       = document.createElement("p");
                date.textContent                 = `Дата ${data.date_application}`;

                const full_name                  = document.createElement("p");
                full_name.textContent            = `ФИО: ${data.full_name}`;

                const phone_number               = document.createElement("p");
                phone_number.textContent         = `Номер телефона ${data.phone_number}`;

                const type_equipment             = document.createElement("p");
                type_equipment.textContent       = `Тип неисправности ${data.type_equipment}`;

                const date_application           = document.createElement("p");
                date_application.textContent     = `Дата окончания ремонта ${data.date_application}`;

                const status                     = document.createElement("p");
                status.textContent               = `Статус заявки ${data.status}`;

                application?.append(date, full_name, phone_number, type_equipment, date_application, status);
            })
            .catch(err => {
                console.error(err);
            });
        }
    };

</script>

<div id="wrapper">
    
        <main>
            <h1>Заявки</h1>
            <input id="phone_number" type="text" placeholder="Номер телефона">
            <button on:click={ViewAplic}>Поиск</button>

            <div id="application"></div>
            
            <a href="/admin/client">Назад</a>
        </main>
</div>


<style>
    main {
        width: 40vw;
        height: auto;
    }

    input {
        padding: 1.25vw;

        width: 30vw;
        height: 3vw;

        font-size: 2vw;
        border: 2px solid #00d9ff;
        border-radius: 1vw;
    }

    button {
        width: 33vw;
        height: 7vw;

        border-radius: 1vw;
        border: 2px solid #00d9ff;
        font-size: 2vw;
    }

    #application {
        width: 77%;
        height: auto;

        display: flex;
        flex-direction: column;
        gap: 0.5vw;
        text-align: center;

        font-size: 2vw;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 1vw;
        border: 2px solid #00d9ff;
    }
</style>