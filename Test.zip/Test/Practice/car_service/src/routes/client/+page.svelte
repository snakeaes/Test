<script lang="ts">
    import "$lib/styles/main.css";

    import Menu from "$lib/components/Menu.svelte";
    const header = "Клиент";
    let buttons: Map<String, String> = new Map();
    buttons.set("/client/add_applic", "Создать заказ");
    buttons.set("/client/view_applic", "Заказы");
    buttons.set("/", "Назад");
</script>

<Menu {header} buttons={buttons}></Menu>