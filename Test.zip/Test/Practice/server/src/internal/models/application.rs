// use tokio_postgres::types::Date; - ?
use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug)]
pub struct Application
{
    pub id: i32,
    pub full_name: String,
    pub phone_number: String,
    pub type_equipment: String,
    pub problem: String,
    pub date_application: String,
    pub status: String
}