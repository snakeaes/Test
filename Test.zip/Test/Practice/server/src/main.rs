mod internal;
use std::error::Error as StdError;
use internal::database::database::{DataBase, InsertBuilder, UpdateBuilder, SelectBuilder};


#[tokio::main]
async fn main() -> Result<(), Box<dyn StdError>> {
    let mut client = DataBase::get_connection().await?;
    DataBase::create_tables(&mut client).await;

    // let mut select_query = SelectBuilder::new("module");
    //     select_query.select_columns("name")
    //         .where_condition("name = 'Костя'");

    // let result_rows = select_query.execute(&mut client).await.unwrap();

    // for row in result_rows {
    //     let id: i32 = row.get(0);
    //     let name: &str = row.get(1);
        
    //     println!("Row Data: ID - {}, Name - {}", id, name);
    // }

    // let mut update_query = UpdateBuilder::new("module")
    //     .set_value("name", "Костя")
    //     .where_condition("name = 'Иван2'")
    //     .execute(&mut client).await.unwrap();

    // let mut inser_query = InsertBuilder::new("module")
    //     .add_column_value("name", "Иван2")
    //     .execute(&mut client).await.unwrap();
    
    internal::transport::server::start().await;
    Ok(())
}