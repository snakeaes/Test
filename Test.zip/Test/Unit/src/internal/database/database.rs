use tokio_postgres::{Client, Error, Row, NoTls};
use std::error::Error as StdError;

pub struct DataBase {
    host: String,
    user: String,
    database_name: String
}


impl DataBase {
    pub async fn get_connection() -> Result<Client, Box<dyn StdError>> {
        let (client, connection) = tokio_postgres::connect("host=localhost user=postgres password=SnakeAes.228 dbname=Unit", NoTls).await?;
        tokio::spawn(connection);
        Ok(client)
    }


    pub async fn create_tables(client: &mut Client) -> Result<(), Box<dyn StdError>> {
        let mut table_builders = vec![
            TableBuilder::new("users")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("full_name", "VARCHAR(100) NOT NULL")
                .add_column("phone_number", "INT NOT NULL")
                .add_column("email", "VARCHAR(50) NOT NULL")
                .add_column("birth", "DATE")
                .add_column("date_employment", "DATE")
                .add_column("id_department", "INT")
                .add_column("id_role", "INT")
                .add_column("login", "VARCHAR(50) NOT NULL")
                .add_column("password", "VARCHAR(50) NOT NULL")
                .add_column("public_key", "TEXT")
                .add_column("private_key", "TEXT"),
            TableBuilder::new("department")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("available_modules", "INTEGER[]"),
            TableBuilder::new("role")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("focused_modules", "INTEGER[]"),
            TableBuilder::new("module")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("name", "VARCHAR(50) NOT NULL"),
            TableBuilder::new("project")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("title", "VARCHAR(50)")
                .add_column("description", "TEXT")
                .add_column("date_started", "DATE")
                .add_column("date_ended", "DATE")
                .add_column("members", "INTEGER[]"),
            TableBuilder::new("phonebook")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("current_task", "INT")
                .add_column("status", "VARCHAR(20) NOT NULL")
                .add_column("time", "DATE"),
            TableBuilder::new("task")
                .add_column("id", "SERIAL PRIMARY KEY")
                .add_column("id_project", "INT")
                .add_column("description", "TEXT")
                .add_column("date_started", "DATE")
                .add_column("date_ended", "DATE"),
        ];

        for table_builder in &mut table_builders {
            table_builder.create_table(client).await?;
        }
        Ok(())
    }
}


pub struct TableBuilder {
    table_name: String,
    columns: Vec<(String, String)>,
}


impl TableBuilder {
    pub fn new(table_name: &str) -> TableBuilder {
        TableBuilder {
            table_name: table_name.to_string(),
            columns: Vec::new(),
        }
    }


    pub fn add_column(mut self, column_name: &str, data_type: &str) -> Self {
        self.columns.push((column_name.to_string(), data_type.to_string()));
        self
    }


    pub async fn create_table(&self, client: &mut Client) -> Result<(), Error> {
        let mut create_table_query = format!("CREATE TABLE IF NOT EXISTS {} (", self.table_name);
        for (i, (column_name, data_type)) in self.columns.iter().enumerate() {
            create_table_query.push_str(&format!(
                "{} {} {}",
                column_name,
                data_type,
                if i == self.columns.len() - 1 { "" } else { "," }
            ));
        }
        create_table_query.push_str(")");

        client.batch_execute(&create_table_query).await
    }
}


pub struct InsertBuilder {
    table: String,
    columns: Vec<String>,
    values: Vec<String>,
    where_conditions: Option<String>,
}


impl InsertBuilder {
    pub fn new(table: &str) -> Self {
        Self {
            table: String::from(table),
            columns: Vec::new(),
            values: Vec::new(),
            where_conditions: None,
        }
    }


    pub fn add_column_value(&mut self, column: &str, value: &str) -> &mut Self {
        self.columns.push(String::from(column));
        self.values.push(String::from(value));
        self
    }


    pub fn where_condition(&mut self, condition: &str) -> &mut Self {
        self.where_conditions = Some(String::from(condition));
        self
    }


    pub async fn execute(&self, client: &mut Client) -> Result<(), Error> {
        let columns_str = self.columns.join(", ");
        let values_str = self.values.iter().map(|v| format!("'{}'", v)).collect::<Vec<String>>().join(", ");
    
        let mut query = format!("INSERT INTO {} ({}) VALUES ({})", self.table, columns_str, values_str);
    
        if let Some(where_cond) = &self.where_conditions {
            query.push_str(" WHERE ");
            query.push_str(where_cond);
        }
    
        client.execute(&query, &[]).await?;
    
        Ok(())
    }
}


pub struct UpdateBuilder {
    table: String,
    set_values: Vec<(String, String)>,
    where_conditions: Option<String>,
}


impl UpdateBuilder {
    pub fn new(table: &str) -> Self {
        Self {
            table: String::from(table),
            set_values: Vec::new(),
            where_conditions: None,
        }
    }


    pub fn set_value(&mut self, column: &str, value: &str) -> &mut Self {
        self.set_values.push((String::from(column), String::from(value)));
        self
    }


    pub fn where_condition(&mut self, condition: &str) -> &mut Self {
        self.where_conditions = Some(String::from(condition));
        self
    }


    pub async fn execute(&self, client: &mut Client) -> Result<(), Error> {
        let set_values_str = self.set_values.iter()
            .map(|(col, val)| format!("{} = '{}'", col, val))
            .collect::<Vec<String>>()
            .join(", ");

        let mut query = format!("UPDATE {} SET {}", self.table, set_values_str);

        if let Some(where_cond) = &self.where_conditions {
            query.push_str(" WHERE ");
            query.push_str(where_cond);
        }

        client.execute(&query, &[]).await?;

        Ok(())
    }
}


pub struct SelectBuilder {
    table: String,
    columns: String,
    where_conditions: Option<String>,
}


impl SelectBuilder {
    pub fn new(table: &str) -> Self {
        Self {
            table: String::from(table),
            columns: String::from("*"),
            where_conditions: None,
        }
    }


    pub fn select_columns(&mut self, columns: &str) -> &mut Self {
        self.columns = String::from(columns);
        self
    }


    pub fn where_condition(&mut self, condition: &str) -> &mut Self {
        self.where_conditions = Some(String::from(condition));
        self
    }

    
    pub async fn execute(&self, client: &mut Client) -> Result<Vec<Row>, Error> {
        let mut query = format!("SELECT {} FROM {}", self.columns, self.table);

        if let Some(where_cond) = &self.where_conditions {
            query.push_str(" WHERE ");
            query.push_str(where_cond);
        }

        let rows = client.query(&query, &[]).await?;

        Ok(rows)
    }
}