pub mod transport 
{
    pub mod server;
    pub mod handler;
}

pub mod database
{
    pub mod database;
}

pub mod models
{
   pub mod department;
   pub mod module;
   pub mod phonebook;
   pub mod project;
   pub mod role;
   pub mod task;
   pub mod user; 
}