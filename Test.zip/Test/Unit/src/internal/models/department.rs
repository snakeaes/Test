pub struct Department
{
    id: u32,
    name: String,
    available_modules: u32
}