pub struct Phonebook
{
    id: u32,
    current_task: u32,
    status: String
    // time - chrono??
}