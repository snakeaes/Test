pub struct Project 
{
    id: u32,
    title: String,
    description: String,
    // avatar - ??
    // date_started - chrono ??
    // date_ended - chrono ??
    members: Vec<u32>
}