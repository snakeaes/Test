pub struct Role
{
    id: u32,
    name: String,
    focused_modules: u32
}