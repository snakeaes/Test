pub struct Task 
{
    id: u32,
    id_project: u32,
    // user.full_name?
    description: String,
    // date_started - chrono ??
    // date_ended - chrono ??
}