// use tokio_postgres::types::Date; - ?

pub struct User
{
    id: u32,
    full_name: String,
    phone_number: u32,
    email: String,
    // birth - chrono? DATE
    // date_employment DATE
    id_department: u32,
    id_role: u32,
    login: String,
    password: String,
    public_key: String,
    private_key: String
}