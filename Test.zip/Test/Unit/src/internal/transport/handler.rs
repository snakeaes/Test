use std::{collections::HashMap};
use serde::{Deserialize};
use std::error::Error as StdError;
use axum::{
    response::IntoResponse, 
    Json
};
use crate::internal::database::database::{DataBase, InsertBuilder, SelectBuilder};

#[derive(Debug, Deserialize)]
struct RequestData {
    operation: String,
    data: HashMap<String, String>,
}


enum Operation {
    Add,
    Get,
    Delete,
    Update,
}


impl Operation {
    pub async fn execute(&self, data: &HashMap<String, String>) -> Result<(), Box<dyn StdError>> {
        match self {
            Operation::Add => {
                println!("Выполняется операция добавления с данными:");

                let mut client = DataBase::get_connection().await?;

                let mut insert_query = InsertBuilder::new("module");
                for (key, value) in data {
                    println!("key - {}, value - {}", &key, &value);
                    insert_query.add_column_value(&key, &value);
                }
                insert_query.execute(&mut client).await?;
            },
            Operation::Get => {
                println!("Выполняется операция получения с данными:");
            },
            Operation::Delete => {
                println!("Выполняется операция удаления с данными:");
            },
            Operation::Update => {
                println!("Выполняется операция обновления с данными:");
            }
        }

        for (key, value) in data.iter() {
            println!("{}: {}", key, value);
        }

        Ok(())
    }
}


pub struct Handler {}


impl Handler {
    async fn get_user() -> Result<String, Box<dyn StdError>> {
        let json_input = r#"{
            "operation": "add",
            "data": {
                "name": "user@mail.ru"
            }
        }"#;

        let request_data: RequestData = serde_json::from_str(json_input)?;

        let operation = match request_data.operation.as_str() {
            "add" => Operation::Add,
            "get" => Operation::Get,
            "delete" => Operation::Delete,
            "update" => Operation::Update,
            _ => panic!("Неизвестная операция"),
        };

        let data = request_data.data;

        operation.execute(&data).await?;

        Ok("test".to_string())
    }


    pub async fn handle_get_user() -> impl IntoResponse {
        match Handler::get_user().await {
            Ok(result) => Ok(Json(result)),
            Err(err) => {
                eprintln!("Error: {:?}", err);
                Err((axum::http::StatusCode::INTERNAL_SERVER_ERROR, "Internal Server Error"))
            }
        }
    }
}
