use crate::internal::transport::handler::Handler;
use axum::{
    routing::get,
    Router,
    response::IntoResponse, Json
};


pub async fn start() {
    let app = Router::new()
        .route("/", get(Handler::handle_get_user));

        let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
        axum::serve(listener, app).await.unwrap();
}